package com.codeforanyone.edujavajsp.model;

public class User {

}
